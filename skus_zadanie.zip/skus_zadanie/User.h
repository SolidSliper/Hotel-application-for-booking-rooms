#pragma once
#include <QString>
#include <map>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <iostream>

class User
{
protected:
    QString name, surname, usrName;

public:
    User() : name(""), surname("") {}
    User(QString n, QString s, QString u) : name(n), surname(s), usrName(u) {}
    QString getUsrName() { return usrName; }
    QString getName() { return name; }
    QString getSurname() { return surname; }
};