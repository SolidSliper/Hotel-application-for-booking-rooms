﻿#include "entrance.h"

entrance::entrance(QWidget* parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
    //initializeUsers(f1, f2, f3);
    connect(ui.loginPushButton, &QPushButton::clicked, this, &entrance::loginning);
}

entrance::~entrance()
{}

void entrance::loginning()
{
    if (ui.passwordLineEdit->text().isEmpty())
    {
        QMessageBox::warning(this, "Login", "Enter password!");
        return;
    }
    QString login = ui.loginComboBox->currentText();
    // Пошук у guestLog
    auto guestIt = guestLog.find(login);
    if (guestIt != guestLog.end()) {
        // Ключ знайдено, перевірка значення
        if (guestIt->second == ui.passwordLineEdit->text()) {
            QMessageBox::information(this, "Login", "Successful login!");
            for (int i = 0; i < guest.size(); i++)  // шукаємо індекс активного користувача
            {
                if (guest[i].getUsrName() == login)
                    indexActiveUsr = i;
            }
            activeUsr[0] = true;
            isG = true;
            emit loginCompleted();
            return;
        }
        else {
            QMessageBox::warning(this, "Login", "Incorrect password!");
            return;
        }
    }

    // Пошук у companyLog
    auto companyIt = companyLog.find(login);
    if (companyIt != companyLog.end()) {
        if (companyIt->second == ui.passwordLineEdit->text()) {
            QMessageBox::information(this, "Login", "Successful login!");
            for (int i = 0; i < company.size(); i++)  // шукаємо індекс активного користувача
            {
                if (company[i].getUsrName() == login)
                    indexActiveUsr = i;
            }
            activeUsr[1] = true;          
            isG = false;
            emit loginCompleted();
            return;
        }
        else {
            QMessageBox::warning(this, "Login", "Incorrect password!");
            return;
        }
    }

    // Пошук у employeeLog
    auto employeeIt = employeeLog.find(login);
    if (employeeIt != employeeLog.end()) {
        // Ключ знайдено, перевірка значення
        if (employeeIt->second == ui.passwordLineEdit->text()) {
            QMessageBox::information(this, "Login", "Successful login!");
            for (int i = 0; i < employee.size(); i++)  // шукаємо індекс активного користувача
            {
                if (employee[i].getUsrName() == login)
                    indexActiveUsr = i;
            }
            activeUsr[2] = true;
            isG = false;
            emit loginCompleted();
            return;
        }
        else {
            QMessageBox::warning(this, "Login", "Incorrect password!");
            return;
        }
    }
}

void entrance::initializeUsers(sql::Connection* con, sql::Statement* stmt, sql::ResultSet* res)
{
    int i = 0;

    try {
        stmt = con->createStatement();
        res = stmt->executeQuery("SELECT * FROM guests");
        while (res->next()) {
            qDebug() << i;
            QString login = QString::fromStdString(res->getString("login"));
            QString passwrd = QString::fromStdString(res->getString("passwrd"));
            QString name = QString::fromStdString(res->getString("name"));
            QString surname = QString::fromStdString(res->getString("surname"));
            QString billing_address = QString::fromStdString(res->getString("billing_address"));

            guestLog[login] = passwrd;
            Guest g = Guest(name, surname, login, billing_address);
            guest.insert(guest.end(), g);
            guest[i].print();

            i++;
        }

        res = stmt->executeQuery("SELECT * FROM companies");
        while (res->next())     // Запис юзернеймів та паролів компаній
        {
            QString login = QString::fromStdString(res->getString("login"));
            QString passwrd = QString::fromStdString(res->getString("passwrd"));
            QString name = QString::fromStdString(res->getString("name"));
            bool VAT_payer = res->getBoolean("VAT_payer");

            companyLog[login] = passwrd;
            Company c = Company(name, login, VAT_payer);
            company.insert(company.end(), c);
        }

        res = stmt->executeQuery("SELECT * FROM employee");
        while (res->next())      // Запис юзернеймів та паролів працівників
        {
            QString login = QString::fromStdString(res->getString("login"));
            QString passwrd = QString::fromStdString(res->getString("passwrd"));
            QString name = QString::fromStdString(res->getString("name"));
            QString surname = QString::fromStdString(res->getString("surname"));
            bool administrator = res->getBoolean("administrator");
            bool receptionist = res->getBoolean("receptionist");

            employeeLog[login] = passwrd;
            Employee e = Employee(name, surname, login, administrator, receptionist);
            employee.insert(employee.end(), e);
        }
    }
    catch (sql::SQLException& e) {
        qDebug() << "SQL error: " << e.what();
    }

    for (Guest& g : guest)
        ui.loginComboBox->addItem(g.getUsrName());

    for (Company& c : company)
        ui.loginComboBox->addItem(c.getUsrName());

    for (Employee& e : employee)
        ui.loginComboBox->addItem(e.getUsrName());
}
