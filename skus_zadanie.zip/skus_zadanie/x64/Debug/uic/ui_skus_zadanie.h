/********************************************************************************
** Form generated from reading UI file 'skus_zadanie.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SKUS_ZADANIE_H
#define UI_SKUS_ZADANIE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_skus_zadanieClass
{
public:
    QAction *actionInvoice;
    QAction *actionLogOut;
    QAction *actionSelectRoomsFile;
    QAction *actionEditUsers;
    QAction *actionEditCompanies;
    QAction *actionEditEmployee;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_5;
    QHBoxLayout *horizontalLayout_6;
    QCalendarWidget *calendarWidget;
    QVBoxLayout *verticalLayout;
    QGroupBox *selectRoomGroupBox;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_2;
    QRadioButton *oneBeddedRadioButton;
    QSpacerItem *horizontalSpacer_2;
    QSpinBox *oneBeddedSpinBox;
    QHBoxLayout *horizontalLayout_3;
    QRadioButton *twoBeddedRadioButton;
    QSpacerItem *horizontalSpacer_3;
    QSpinBox *twoBeddedSpinBox;
    QHBoxLayout *horizontalLayout_4;
    QRadioButton *fourBeddedRadioButton;
    QSpacerItem *horizontalSpacer_4;
    QSpinBox *fourBeddedSpinBox;
    QGroupBox *reservationGroupBox;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *confirmPushButton;
    QSpacerItem *horizontalSpacer;
    QPushButton *cancelPushButton;
    QHBoxLayout *horizontalLayout;
    QLabel *labelGreen;
    QSpacerItem *horizontalSpacer_5;
    QLabel *labelMagenta;
    QLabel *label;
    QGroupBox *usersReservationsGroupBox;
    QVBoxLayout *verticalLayout_4;
    QListWidget *listWidget;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuAccount;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *skus_zadanieClass)
    {
        if (skus_zadanieClass->objectName().isEmpty())
            skus_zadanieClass->setObjectName("skus_zadanieClass");
        skus_zadanieClass->resize(733, 541);
        actionInvoice = new QAction(skus_zadanieClass);
        actionInvoice->setObjectName("actionInvoice");
        actionLogOut = new QAction(skus_zadanieClass);
        actionLogOut->setObjectName("actionLogOut");
        actionSelectRoomsFile = new QAction(skus_zadanieClass);
        actionSelectRoomsFile->setObjectName("actionSelectRoomsFile");
        actionEditUsers = new QAction(skus_zadanieClass);
        actionEditUsers->setObjectName("actionEditUsers");
        actionEditCompanies = new QAction(skus_zadanieClass);
        actionEditCompanies->setObjectName("actionEditCompanies");
        actionEditEmployee = new QAction(skus_zadanieClass);
        actionEditEmployee->setObjectName("actionEditEmployee");
        centralWidget = new QWidget(skus_zadanieClass);
        centralWidget->setObjectName("centralWidget");
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName("verticalLayout_5");
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        calendarWidget = new QCalendarWidget(centralWidget);
        calendarWidget->setObjectName("calendarWidget");

        horizontalLayout_6->addWidget(calendarWidget);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName("verticalLayout");
        selectRoomGroupBox = new QGroupBox(centralWidget);
        selectRoomGroupBox->setObjectName("selectRoomGroupBox");
        verticalLayout_2 = new QVBoxLayout(selectRoomGroupBox);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName("verticalLayout_2");
        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        oneBeddedRadioButton = new QRadioButton(selectRoomGroupBox);
        oneBeddedRadioButton->setObjectName("oneBeddedRadioButton");

        horizontalLayout_2->addWidget(oneBeddedRadioButton);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        oneBeddedSpinBox = new QSpinBox(selectRoomGroupBox);
        oneBeddedSpinBox->setObjectName("oneBeddedSpinBox");
        oneBeddedSpinBox->setReadOnly(true);
        oneBeddedSpinBox->setButtonSymbols(QAbstractSpinBox::NoButtons);

        horizontalLayout_2->addWidget(oneBeddedSpinBox);


        verticalLayout_2->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        twoBeddedRadioButton = new QRadioButton(selectRoomGroupBox);
        twoBeddedRadioButton->setObjectName("twoBeddedRadioButton");

        horizontalLayout_3->addWidget(twoBeddedRadioButton);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_3);

        twoBeddedSpinBox = new QSpinBox(selectRoomGroupBox);
        twoBeddedSpinBox->setObjectName("twoBeddedSpinBox");
        twoBeddedSpinBox->setReadOnly(true);
        twoBeddedSpinBox->setButtonSymbols(QAbstractSpinBox::NoButtons);

        horizontalLayout_3->addWidget(twoBeddedSpinBox);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        fourBeddedRadioButton = new QRadioButton(selectRoomGroupBox);
        fourBeddedRadioButton->setObjectName("fourBeddedRadioButton");

        horizontalLayout_4->addWidget(fourBeddedRadioButton);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_4);

        fourBeddedSpinBox = new QSpinBox(selectRoomGroupBox);
        fourBeddedSpinBox->setObjectName("fourBeddedSpinBox");
        fourBeddedSpinBox->setReadOnly(true);
        fourBeddedSpinBox->setButtonSymbols(QAbstractSpinBox::NoButtons);

        horizontalLayout_4->addWidget(fourBeddedSpinBox);


        verticalLayout_2->addLayout(horizontalLayout_4);


        verticalLayout->addWidget(selectRoomGroupBox);

        reservationGroupBox = new QGroupBox(centralWidget);
        reservationGroupBox->setObjectName("reservationGroupBox");
        verticalLayout_3 = new QVBoxLayout(reservationGroupBox);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName("verticalLayout_3");
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        confirmPushButton = new QPushButton(reservationGroupBox);
        confirmPushButton->setObjectName("confirmPushButton");

        horizontalLayout_5->addWidget(confirmPushButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer);

        cancelPushButton = new QPushButton(reservationGroupBox);
        cancelPushButton->setObjectName("cancelPushButton");

        horizontalLayout_5->addWidget(cancelPushButton);


        verticalLayout_3->addLayout(horizontalLayout_5);


        verticalLayout->addWidget(reservationGroupBox);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName("horizontalLayout");
        labelGreen = new QLabel(centralWidget);
        labelGreen->setObjectName("labelGreen");

        horizontalLayout->addWidget(labelGreen);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_5);

        labelMagenta = new QLabel(centralWidget);
        labelMagenta->setObjectName("labelMagenta");

        horizontalLayout->addWidget(labelMagenta);


        verticalLayout->addLayout(horizontalLayout);

        label = new QLabel(centralWidget);
        label->setObjectName("label");

        verticalLayout->addWidget(label);


        horizontalLayout_6->addLayout(verticalLayout);


        verticalLayout_5->addLayout(horizontalLayout_6);

        usersReservationsGroupBox = new QGroupBox(centralWidget);
        usersReservationsGroupBox->setObjectName("usersReservationsGroupBox");
        verticalLayout_4 = new QVBoxLayout(usersReservationsGroupBox);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName("verticalLayout_4");
        listWidget = new QListWidget(usersReservationsGroupBox);
        listWidget->setObjectName("listWidget");

        verticalLayout_4->addWidget(listWidget);


        verticalLayout_5->addWidget(usersReservationsGroupBox);


        gridLayout->addLayout(verticalLayout_5, 0, 0, 1, 1);

        skus_zadanieClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(skus_zadanieClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 733, 22));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName("menuFile");
        menuAccount = new QMenu(menuBar);
        menuAccount->setObjectName("menuAccount");
        skus_zadanieClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(skus_zadanieClass);
        mainToolBar->setObjectName("mainToolBar");
        skus_zadanieClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(skus_zadanieClass);
        statusBar->setObjectName("statusBar");
        skus_zadanieClass->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuAccount->menuAction());
        menuFile->addAction(actionInvoice);
        menuFile->addAction(actionSelectRoomsFile);
        menuFile->addAction(actionEditUsers);
        menuAccount->addAction(actionLogOut);

        retranslateUi(skus_zadanieClass);

        QMetaObject::connectSlotsByName(skus_zadanieClass);
    } // setupUi

    void retranslateUi(QMainWindow *skus_zadanieClass)
    {
        skus_zadanieClass->setWindowTitle(QCoreApplication::translate("skus_zadanieClass", "skus_zadanie", nullptr));
        actionInvoice->setText(QCoreApplication::translate("skus_zadanieClass", "Invoice", nullptr));
        actionLogOut->setText(QCoreApplication::translate("skus_zadanieClass", "Log Out", nullptr));
        actionSelectRoomsFile->setText(QCoreApplication::translate("skus_zadanieClass", "Select rooms file", nullptr));
        actionEditUsers->setText(QCoreApplication::translate("skus_zadanieClass", "Edit users", nullptr));
        actionEditCompanies->setText(QCoreApplication::translate("skus_zadanieClass", "Edit companies", nullptr));
        actionEditEmployee->setText(QCoreApplication::translate("skus_zadanieClass", "Edit employee", nullptr));
        selectRoomGroupBox->setTitle(QCoreApplication::translate("skus_zadanieClass", "Select room", nullptr));
        oneBeddedRadioButton->setText(QCoreApplication::translate("skus_zadanieClass", "1-bedded rooms", nullptr));
        twoBeddedRadioButton->setText(QCoreApplication::translate("skus_zadanieClass", "2-bedded rooms", nullptr));
        fourBeddedRadioButton->setText(QCoreApplication::translate("skus_zadanieClass", "4 bedded rooms", nullptr));
        reservationGroupBox->setTitle(QCoreApplication::translate("skus_zadanieClass", "Reservation", nullptr));
        confirmPushButton->setText(QCoreApplication::translate("skus_zadanieClass", "Confirm", nullptr));
        cancelPushButton->setText(QCoreApplication::translate("skus_zadanieClass", "Cancel", nullptr));
        labelGreen->setText(QCoreApplication::translate("skus_zadanieClass", "*magenta date - reservated", nullptr));
        labelMagenta->setText(QCoreApplication::translate("skus_zadanieClass", "*green date - confirmed reservation", nullptr));
        label->setText(QCoreApplication::translate("skus_zadanieClass", "*red date - canceled reservation(except on weekends, they are always red)", nullptr));
        usersReservationsGroupBox->setTitle(QCoreApplication::translate("skus_zadanieClass", "Your reservations", nullptr));
        menuFile->setTitle(QCoreApplication::translate("skus_zadanieClass", "File", nullptr));
        menuAccount->setTitle(QCoreApplication::translate("skus_zadanieClass", "Account", nullptr));
    } // retranslateUi

};

namespace Ui {
    class skus_zadanieClass: public Ui_skus_zadanieClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SKUS_ZADANIE_H
