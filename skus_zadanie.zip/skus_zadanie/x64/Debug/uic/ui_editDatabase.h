/********************************************************************************
** Form generated from reading UI file 'editDatabase.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EDITDATABASE_H
#define UI_EDITDATABASE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_editDatabaseClass
{
public:
    QAction *actionOpen;
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    QTextEdit *textEdit;
    QHBoxLayout *horizontalLayout;
    QCheckBox *employeeCheckBox;
    QSpacerItem *horizontalSpacer;
    QPushButton *editPushButton;
    QPushButton *exitPushButton;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *editDatabaseClass)
    {
        if (editDatabaseClass->objectName().isEmpty())
            editDatabaseClass->setObjectName("editDatabaseClass");
        editDatabaseClass->resize(600, 400);
        actionOpen = new QAction(editDatabaseClass);
        actionOpen->setObjectName("actionOpen");
        centralWidget = new QWidget(editDatabaseClass);
        centralWidget->setObjectName("centralWidget");
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName("verticalLayout");
        textEdit = new QTextEdit(centralWidget);
        textEdit->setObjectName("textEdit");

        verticalLayout->addWidget(textEdit);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName("horizontalLayout");
        employeeCheckBox = new QCheckBox(centralWidget);
        employeeCheckBox->setObjectName("employeeCheckBox");

        horizontalLayout->addWidget(employeeCheckBox);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        editPushButton = new QPushButton(centralWidget);
        editPushButton->setObjectName("editPushButton");

        horizontalLayout->addWidget(editPushButton);

        exitPushButton = new QPushButton(centralWidget);
        exitPushButton->setObjectName("exitPushButton");

        horizontalLayout->addWidget(exitPushButton);


        verticalLayout->addLayout(horizontalLayout);


        gridLayout->addLayout(verticalLayout, 0, 0, 1, 1);

        editDatabaseClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(editDatabaseClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 600, 22));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName("menuFile");
        editDatabaseClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(editDatabaseClass);
        mainToolBar->setObjectName("mainToolBar");
        editDatabaseClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(editDatabaseClass);
        statusBar->setObjectName("statusBar");
        editDatabaseClass->setStatusBar(statusBar);

        menuBar->addAction(menuFile->menuAction());
        menuFile->addAction(actionOpen);

        retranslateUi(editDatabaseClass);

        QMetaObject::connectSlotsByName(editDatabaseClass);
    } // setupUi

    void retranslateUi(QMainWindow *editDatabaseClass)
    {
        editDatabaseClass->setWindowTitle(QCoreApplication::translate("editDatabaseClass", "editDatabase", nullptr));
        actionOpen->setText(QCoreApplication::translate("editDatabaseClass", "Open", nullptr));
        employeeCheckBox->setText(QCoreApplication::translate("editDatabaseClass", "Employee", nullptr));
        editPushButton->setText(QCoreApplication::translate("editDatabaseClass", "Edit", nullptr));
        exitPushButton->setText(QCoreApplication::translate("editDatabaseClass", "Exit", nullptr));
        menuFile->setTitle(QCoreApplication::translate("editDatabaseClass", "File", nullptr));
    } // retranslateUi

};

namespace Ui {
    class editDatabaseClass: public Ui_editDatabaseClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EDITDATABASE_H
