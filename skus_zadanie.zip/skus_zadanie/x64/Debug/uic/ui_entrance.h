/********************************************************************************
** Form generated from reading UI file 'entrance.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ENTRANCE_H
#define UI_ENTRANCE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_entranceClass
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_3;
    QGroupBox *groupBox;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QComboBox *loginComboBox;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_2;
    QLineEdit *passwordLineEdit;
    QPushButton *loginPushButton;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *entranceClass)
    {
        if (entranceClass->objectName().isEmpty())
            entranceClass->setObjectName("entranceClass");
        entranceClass->resize(339, 248);
        centralWidget = new QWidget(entranceClass);
        centralWidget->setObjectName("centralWidget");
        gridLayout = new QGridLayout(centralWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName("verticalLayout_2");
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName("label_3");
        QFont font;
        font.setFamilies({QString::fromUtf8("Times New Roman")});
        font.setPointSize(14);
        font.setBold(false);
        label_3->setFont(font);

        verticalLayout_2->addWidget(label_3);

        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName("groupBox");
        verticalLayout = new QVBoxLayout(groupBox);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName("verticalLayout");
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName("horizontalLayout");
        label = new QLabel(groupBox);
        label->setObjectName("label");

        horizontalLayout->addWidget(label);

        loginComboBox = new QComboBox(groupBox);
        loginComboBox->setObjectName("loginComboBox");

        horizontalLayout->addWidget(loginComboBox);


        verticalLayout->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        label_2 = new QLabel(groupBox);
        label_2->setObjectName("label_2");

        horizontalLayout_2->addWidget(label_2);

        passwordLineEdit = new QLineEdit(groupBox);
        passwordLineEdit->setObjectName("passwordLineEdit");

        horizontalLayout_2->addWidget(passwordLineEdit);


        verticalLayout->addLayout(horizontalLayout_2);


        verticalLayout_2->addWidget(groupBox);

        loginPushButton = new QPushButton(centralWidget);
        loginPushButton->setObjectName("loginPushButton");

        verticalLayout_2->addWidget(loginPushButton);


        gridLayout->addLayout(verticalLayout_2, 0, 0, 1, 1);

        entranceClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(entranceClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 339, 22));
        entranceClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(entranceClass);
        mainToolBar->setObjectName("mainToolBar");
        entranceClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(entranceClass);
        statusBar->setObjectName("statusBar");
        entranceClass->setStatusBar(statusBar);

        retranslateUi(entranceClass);

        QMetaObject::connectSlotsByName(entranceClass);
    } // setupUi

    void retranslateUi(QMainWindow *entranceClass)
    {
        entranceClass->setWindowTitle(QCoreApplication::translate("entranceClass", "entrance", nullptr));
        label_3->setText(QCoreApplication::translate("entranceClass", "Welcome to the room reservation system!", nullptr));
        groupBox->setTitle(QCoreApplication::translate("entranceClass", "SignIn", nullptr));
        label->setText(QCoreApplication::translate("entranceClass", "Username:", nullptr));
        label_2->setText(QCoreApplication::translate("entranceClass", "Password:", nullptr));
        loginPushButton->setText(QCoreApplication::translate("entranceClass", "Login", nullptr));
    } // retranslateUi

};

namespace Ui {
    class entranceClass: public Ui_entranceClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ENTRANCE_H
