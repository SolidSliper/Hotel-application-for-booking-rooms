/****************************************************************************
** Meta object code from reading C++ file 'skus_zadanie.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../skus_zadanie.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'skus_zadanie.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSskus_zadanieENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSskus_zadanieENDCLASS = QtMocHelpers::stringData(
    "skus_zadanie",
    "showWindow",
    "",
    "confirmReservation",
    "cancelReservation",
    "loggingOut",
    "dateReservationSelected",
    "QListWidgetItem*",
    "item",
    "changeRoomsFile",
    "editDatabaseUsers",
    "createInvoice"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSskus_zadanieENDCLASS_t {
    uint offsetsAndSizes[24];
    char stringdata0[13];
    char stringdata1[11];
    char stringdata2[1];
    char stringdata3[19];
    char stringdata4[18];
    char stringdata5[11];
    char stringdata6[24];
    char stringdata7[17];
    char stringdata8[5];
    char stringdata9[16];
    char stringdata10[18];
    char stringdata11[14];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSskus_zadanieENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSskus_zadanieENDCLASS_t qt_meta_stringdata_CLASSskus_zadanieENDCLASS = {
    {
        QT_MOC_LITERAL(0, 12),  // "skus_zadanie"
        QT_MOC_LITERAL(13, 10),  // "showWindow"
        QT_MOC_LITERAL(24, 0),  // ""
        QT_MOC_LITERAL(25, 18),  // "confirmReservation"
        QT_MOC_LITERAL(44, 17),  // "cancelReservation"
        QT_MOC_LITERAL(62, 10),  // "loggingOut"
        QT_MOC_LITERAL(73, 23),  // "dateReservationSelected"
        QT_MOC_LITERAL(97, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(114, 4),  // "item"
        QT_MOC_LITERAL(119, 15),  // "changeRoomsFile"
        QT_MOC_LITERAL(135, 17),  // "editDatabaseUsers"
        QT_MOC_LITERAL(153, 13)   // "createInvoice"
    },
    "skus_zadanie",
    "showWindow",
    "",
    "confirmReservation",
    "cancelReservation",
    "loggingOut",
    "dateReservationSelected",
    "QListWidgetItem*",
    "item",
    "changeRoomsFile",
    "editDatabaseUsers",
    "createInvoice"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSskus_zadanieENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
       8,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   62,    2, 0x08,    1 /* Private */,
       3,    0,   63,    2, 0x08,    2 /* Private */,
       4,    0,   64,    2, 0x08,    3 /* Private */,
       5,    0,   65,    2, 0x08,    4 /* Private */,
       6,    1,   66,    2, 0x08,    5 /* Private */,
       9,    0,   69,    2, 0x08,    7 /* Private */,
      10,    0,   70,    2, 0x08,    8 /* Private */,
      11,    0,   71,    2, 0x08,    9 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject skus_zadanie::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSskus_zadanieENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSskus_zadanieENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSskus_zadanieENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<skus_zadanie, std::true_type>,
        // method 'showWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'confirmReservation'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cancelReservation'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'loggingOut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dateReservationSelected'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'changeRoomsFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'editDatabaseUsers'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'createInvoice'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void skus_zadanie::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<skus_zadanie *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showWindow(); break;
        case 1: _t->confirmReservation(); break;
        case 2: _t->cancelReservation(); break;
        case 3: _t->loggingOut(); break;
        case 4: _t->dateReservationSelected((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 5: _t->changeRoomsFile(); break;
        case 6: _t->editDatabaseUsers(); break;
        case 7: _t->createInvoice(); break;
        default: ;
        }
    }
}

const QMetaObject *skus_zadanie::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *skus_zadanie::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSskus_zadanieENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int skus_zadanie::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 8)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 8;
    }
    return _id;
}
QT_WARNING_POP
