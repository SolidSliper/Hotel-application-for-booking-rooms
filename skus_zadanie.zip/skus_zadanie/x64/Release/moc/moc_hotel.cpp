/****************************************************************************
** Meta object code from reading C++ file 'hotel.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../hotel.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'hotel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASShotelENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASShotelENDCLASS = QtMocHelpers::stringData(
    "hotel",
    "showWindow",
    "",
    "loggingOut",
    "dateReservationSelected",
    "QListWidgetItem*",
    "item",
    "changeRoomsFile",
    "editDatabaseUsers",
    "createInvoice",
    "handleButtonRoomCheck",
    "on_confirmPushButton_clicked",
    "on_cancelPushButton_clicked",
    "on_pushButtonInfo_clicked",
    "on_pushButtonUa_clicked",
    "on_pushButtonEng_clicked"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASShotelENDCLASS_t {
    uint offsetsAndSizes[32];
    char stringdata0[6];
    char stringdata1[11];
    char stringdata2[1];
    char stringdata3[11];
    char stringdata4[24];
    char stringdata5[17];
    char stringdata6[5];
    char stringdata7[16];
    char stringdata8[18];
    char stringdata9[14];
    char stringdata10[22];
    char stringdata11[29];
    char stringdata12[28];
    char stringdata13[26];
    char stringdata14[24];
    char stringdata15[25];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASShotelENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASShotelENDCLASS_t qt_meta_stringdata_CLASShotelENDCLASS = {
    {
        QT_MOC_LITERAL(0, 5),  // "hotel"
        QT_MOC_LITERAL(6, 10),  // "showWindow"
        QT_MOC_LITERAL(17, 0),  // ""
        QT_MOC_LITERAL(18, 10),  // "loggingOut"
        QT_MOC_LITERAL(29, 23),  // "dateReservationSelected"
        QT_MOC_LITERAL(53, 16),  // "QListWidgetItem*"
        QT_MOC_LITERAL(70, 4),  // "item"
        QT_MOC_LITERAL(75, 15),  // "changeRoomsFile"
        QT_MOC_LITERAL(91, 17),  // "editDatabaseUsers"
        QT_MOC_LITERAL(109, 13),  // "createInvoice"
        QT_MOC_LITERAL(123, 21),  // "handleButtonRoomCheck"
        QT_MOC_LITERAL(145, 28),  // "on_confirmPushButton_clicked"
        QT_MOC_LITERAL(174, 27),  // "on_cancelPushButton_clicked"
        QT_MOC_LITERAL(202, 25),  // "on_pushButtonInfo_clicked"
        QT_MOC_LITERAL(228, 23),  // "on_pushButtonUa_clicked"
        QT_MOC_LITERAL(252, 24)   // "on_pushButtonEng_clicked"
    },
    "hotel",
    "showWindow",
    "",
    "loggingOut",
    "dateReservationSelected",
    "QListWidgetItem*",
    "item",
    "changeRoomsFile",
    "editDatabaseUsers",
    "createInvoice",
    "handleButtonRoomCheck",
    "on_confirmPushButton_clicked",
    "on_cancelPushButton_clicked",
    "on_pushButtonInfo_clicked",
    "on_pushButtonUa_clicked",
    "on_pushButtonEng_clicked"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASShotelENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   86,    2, 0x08,    1 /* Private */,
       3,    0,   87,    2, 0x08,    2 /* Private */,
       4,    1,   88,    2, 0x08,    3 /* Private */,
       7,    0,   91,    2, 0x08,    5 /* Private */,
       8,    0,   92,    2, 0x08,    6 /* Private */,
       9,    0,   93,    2, 0x08,    7 /* Private */,
      10,    0,   94,    2, 0x08,    8 /* Private */,
      11,    0,   95,    2, 0x08,    9 /* Private */,
      12,    0,   96,    2, 0x08,   10 /* Private */,
      13,    0,   97,    2, 0x08,   11 /* Private */,
      14,    0,   98,    2, 0x08,   12 /* Private */,
      15,    0,   99,    2, 0x08,   13 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject hotel::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASShotelENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASShotelENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASShotelENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<hotel, std::true_type>,
        // method 'showWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'loggingOut'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'dateReservationSelected'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QListWidgetItem *, std::false_type>,
        // method 'changeRoomsFile'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'editDatabaseUsers'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'createInvoice'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'handleButtonRoomCheck'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_confirmPushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_cancelPushButton_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonInfo_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonUa_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButtonEng_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void hotel::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<hotel *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showWindow(); break;
        case 1: _t->loggingOut(); break;
        case 2: _t->dateReservationSelected((*reinterpret_cast< std::add_pointer_t<QListWidgetItem*>>(_a[1]))); break;
        case 3: _t->changeRoomsFile(); break;
        case 4: _t->editDatabaseUsers(); break;
        case 5: _t->createInvoice(); break;
        case 6: _t->handleButtonRoomCheck(); break;
        case 7: _t->on_confirmPushButton_clicked(); break;
        case 8: _t->on_cancelPushButton_clicked(); break;
        case 9: _t->on_pushButtonInfo_clicked(); break;
        case 10: _t->on_pushButtonUa_clicked(); break;
        case 11: _t->on_pushButtonEng_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *hotel::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *hotel::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASShotelENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int hotel::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 12;
    }
    return _id;
}
QT_WARNING_POP
