/********************************************************************************
** Form generated from reading UI file 'hotel.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOTEL_H
#define UI_HOTEL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QDockWidget>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QToolButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_hotelClass
{
public:
    QAction *actionInvoice;
    QAction *actionLogOut;
    QAction *actionSelectRoomsFile;
    QAction *actionEditUsers;
    QAction *actionEditCompanies;
    QAction *actionEditEmployee;
    QWidget *centralWidget;
    QGridLayout *gridLayout_2;
    QHBoxLayout *horizontalLayout_4;
    QVBoxLayout *verticalLayout_5;
    QCalendarWidget *calendarWidget;
    QVBoxLayout *verticalLayout;
    QGroupBox *usersReservationsGroupBox;
    QVBoxLayout *verticalLayout_4;
    QListWidget *listWidget;
    QSpacerItem *verticalSpacer;
    QSpacerItem *verticalSpacer_6;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButtonInfo;
    QSpacerItem *horizontalSpacer_2;
    QVBoxLayout *verticalLayout_2;
    QToolBox *toolBox;
    QWidget *floor_1;
    QVBoxLayout *verticalLayout_8;
    QHBoxLayout *horizontalLayout_3;
    QVBoxLayout *verticalLayout_6;
    QToolButton *toolButton103;
    QToolButton *toolButton102;
    QToolButton *toolButton101;
    QVBoxLayout *verticalLayout_7;
    QToolButton *toolButton104;
    QToolButton *toolButton105;
    QToolButton *toolButton106;
    QWidget *floor_2;
    QVBoxLayout *verticalLayout_11;
    QHBoxLayout *horizontalLayout_6;
    QVBoxLayout *verticalLayout_9;
    QToolButton *toolButton203;
    QToolButton *toolButton202;
    QToolButton *toolButton201;
    QVBoxLayout *verticalLayout_10;
    QToolButton *toolButton204;
    QToolButton *toolButton205;
    QToolButton *toolButton206;
    QWidget *floor3;
    QHBoxLayout *horizontalLayout_7;
    QVBoxLayout *verticalLayout_12;
    QToolButton *toolButton302;
    QToolButton *toolButton301;
    QVBoxLayout *verticalLayout_13;
    QToolButton *toolButton303;
    QToolButton *toolButton304;
    QGroupBox *reservationGroupBox;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *confirmPushButton;
    QSpacerItem *horizontalSpacer;
    QPushButton *cancelPushButton;
    QHBoxLayout *horizontalLayout;
    QLabel *labelMagenta;
    QSpacerItem *horizontalSpacer_5;
    QLabel *labelGreen;
    QLabel *labelRed;
    QSpacerItem *verticalSpacer_2;
    QMenuBar *menuBar;
    QMenu *menuFile;
    QMenu *menuAccount;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QDockWidget *dockWidget;
    QWidget *dockWidgetContents;
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout_14;
    QLabel *labelContact;
    QLabel *labelEmail;
    QLabel *labelPhone;
    QSpacerItem *verticalSpacer_4;
    QVBoxLayout *verticalLayout_16;
    QLabel *labelSocial;
    QLabel *labelFacebook;
    QLabel *labelTelegram;
    QHBoxLayout *horizontalLayout_9;
    QLabel *labelInstagram;
    QHBoxLayout *horizontalLayout_8;
    QSpacerItem *horizontalSpacer_3;
    QPushButton *pushButtonUa;
    QPushButton *pushButtonEng;
    QVBoxLayout *verticalLayout_15;
    QLabel *labelAddress_1;
    QLabel *labelAddress_2;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *verticalSpacer_5;

    void setupUi(QMainWindow *hotelClass)
    {
        if (hotelClass->objectName().isEmpty())
            hotelClass->setObjectName("hotelClass");
        hotelClass->resize(886, 671);
        hotelClass->setStyleSheet(QString::fromUtf8(""));
        actionInvoice = new QAction(hotelClass);
        actionInvoice->setObjectName("actionInvoice");
        actionLogOut = new QAction(hotelClass);
        actionLogOut->setObjectName("actionLogOut");
        actionSelectRoomsFile = new QAction(hotelClass);
        actionSelectRoomsFile->setObjectName("actionSelectRoomsFile");
        actionEditUsers = new QAction(hotelClass);
        actionEditUsers->setObjectName("actionEditUsers");
        actionEditCompanies = new QAction(hotelClass);
        actionEditCompanies->setObjectName("actionEditCompanies");
        actionEditEmployee = new QAction(hotelClass);
        actionEditEmployee->setObjectName("actionEditEmployee");
        centralWidget = new QWidget(hotelClass);
        centralWidget->setObjectName("centralWidget");
        gridLayout_2 = new QGridLayout(centralWidget);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName("gridLayout_2");
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setObjectName("verticalLayout_5");
        calendarWidget = new QCalendarWidget(centralWidget);
        calendarWidget->setObjectName("calendarWidget");

        verticalLayout_5->addWidget(calendarWidget);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName("verticalLayout");
        usersReservationsGroupBox = new QGroupBox(centralWidget);
        usersReservationsGroupBox->setObjectName("usersReservationsGroupBox");
        verticalLayout_4 = new QVBoxLayout(usersReservationsGroupBox);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName("verticalLayout_4");
        listWidget = new QListWidget(usersReservationsGroupBox);
        listWidget->setObjectName("listWidget");

        verticalLayout_4->addWidget(listWidget);


        verticalLayout->addWidget(usersReservationsGroupBox);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        verticalSpacer_6 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_6);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        pushButtonInfo = new QPushButton(centralWidget);
        pushButtonInfo->setObjectName("pushButtonInfo");

        horizontalLayout_2->addWidget(pushButtonInfo);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_2);


        verticalLayout_5->addLayout(verticalLayout);


        horizontalLayout_4->addLayout(verticalLayout_5);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setObjectName("verticalLayout_2");
        toolBox = new QToolBox(centralWidget);
        toolBox->setObjectName("toolBox");
        floor_1 = new QWidget();
        floor_1->setObjectName("floor_1");
        floor_1->setGeometry(QRect(0, 0, 428, 100));
        verticalLayout_8 = new QVBoxLayout(floor_1);
        verticalLayout_8->setSpacing(6);
        verticalLayout_8->setContentsMargins(11, 11, 11, 11);
        verticalLayout_8->setObjectName("verticalLayout_8");
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName("verticalLayout_6");
        toolButton103 = new QToolButton(floor_1);
        toolButton103->setObjectName("toolButton103");
        toolButton103->setCheckable(true);

        verticalLayout_6->addWidget(toolButton103);

        toolButton102 = new QToolButton(floor_1);
        toolButton102->setObjectName("toolButton102");
        toolButton102->setCheckable(true);

        verticalLayout_6->addWidget(toolButton102);

        toolButton101 = new QToolButton(floor_1);
        toolButton101->setObjectName("toolButton101");
        toolButton101->setCheckable(true);

        verticalLayout_6->addWidget(toolButton101);


        horizontalLayout_3->addLayout(verticalLayout_6);

        verticalLayout_7 = new QVBoxLayout();
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setObjectName("verticalLayout_7");
        toolButton104 = new QToolButton(floor_1);
        toolButton104->setObjectName("toolButton104");
        toolButton104->setCheckable(true);

        verticalLayout_7->addWidget(toolButton104);

        toolButton105 = new QToolButton(floor_1);
        toolButton105->setObjectName("toolButton105");
        toolButton105->setCheckable(true);

        verticalLayout_7->addWidget(toolButton105);

        toolButton106 = new QToolButton(floor_1);
        toolButton106->setObjectName("toolButton106");
        toolButton106->setCheckable(true);

        verticalLayout_7->addWidget(toolButton106);


        horizontalLayout_3->addLayout(verticalLayout_7);


        verticalLayout_8->addLayout(horizontalLayout_3);

        toolBox->addItem(floor_1, QString::fromUtf8("Floor 1 - One bedded rooms"));
        floor_2 = new QWidget();
        floor_2->setObjectName("floor_2");
        floor_2->setGeometry(QRect(0, 0, 428, 100));
        verticalLayout_11 = new QVBoxLayout(floor_2);
        verticalLayout_11->setSpacing(6);
        verticalLayout_11->setContentsMargins(11, 11, 11, 11);
        verticalLayout_11->setObjectName("verticalLayout_11");
        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName("horizontalLayout_6");
        verticalLayout_9 = new QVBoxLayout();
        verticalLayout_9->setSpacing(6);
        verticalLayout_9->setObjectName("verticalLayout_9");
        toolButton203 = new QToolButton(floor_2);
        toolButton203->setObjectName("toolButton203");
        toolButton203->setCheckable(true);

        verticalLayout_9->addWidget(toolButton203);

        toolButton202 = new QToolButton(floor_2);
        toolButton202->setObjectName("toolButton202");
        toolButton202->setCheckable(true);

        verticalLayout_9->addWidget(toolButton202);

        toolButton201 = new QToolButton(floor_2);
        toolButton201->setObjectName("toolButton201");
        toolButton201->setCheckable(true);

        verticalLayout_9->addWidget(toolButton201);


        horizontalLayout_6->addLayout(verticalLayout_9);

        verticalLayout_10 = new QVBoxLayout();
        verticalLayout_10->setSpacing(6);
        verticalLayout_10->setObjectName("verticalLayout_10");
        toolButton204 = new QToolButton(floor_2);
        toolButton204->setObjectName("toolButton204");
        toolButton204->setCheckable(true);

        verticalLayout_10->addWidget(toolButton204);

        toolButton205 = new QToolButton(floor_2);
        toolButton205->setObjectName("toolButton205");
        toolButton205->setCheckable(true);

        verticalLayout_10->addWidget(toolButton205);

        toolButton206 = new QToolButton(floor_2);
        toolButton206->setObjectName("toolButton206");
        toolButton206->setCheckable(true);

        verticalLayout_10->addWidget(toolButton206);


        horizontalLayout_6->addLayout(verticalLayout_10);


        verticalLayout_11->addLayout(horizontalLayout_6);

        toolBox->addItem(floor_2, QString::fromUtf8("Floor 2 - Two bedded rooms"));
        floor3 = new QWidget();
        floor3->setObjectName("floor3");
        floor3->setGeometry(QRect(0, 0, 428, 70));
        horizontalLayout_7 = new QHBoxLayout(floor3);
        horizontalLayout_7->setSpacing(6);
        horizontalLayout_7->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_7->setObjectName("horizontalLayout_7");
        verticalLayout_12 = new QVBoxLayout();
        verticalLayout_12->setSpacing(6);
        verticalLayout_12->setObjectName("verticalLayout_12");
        toolButton302 = new QToolButton(floor3);
        toolButton302->setObjectName("toolButton302");
        toolButton302->setCheckable(true);

        verticalLayout_12->addWidget(toolButton302);

        toolButton301 = new QToolButton(floor3);
        toolButton301->setObjectName("toolButton301");
        toolButton301->setCheckable(true);

        verticalLayout_12->addWidget(toolButton301);


        horizontalLayout_7->addLayout(verticalLayout_12);

        verticalLayout_13 = new QVBoxLayout();
        verticalLayout_13->setSpacing(6);
        verticalLayout_13->setObjectName("verticalLayout_13");
        toolButton303 = new QToolButton(floor3);
        toolButton303->setObjectName("toolButton303");
        toolButton303->setCheckable(true);

        verticalLayout_13->addWidget(toolButton303);

        toolButton304 = new QToolButton(floor3);
        toolButton304->setObjectName("toolButton304");
        toolButton304->setCheckable(true);

        verticalLayout_13->addWidget(toolButton304);


        horizontalLayout_7->addLayout(verticalLayout_13);

        toolBox->addItem(floor3, QString::fromUtf8("Floor 3 - Four bedded rooms"));

        verticalLayout_2->addWidget(toolBox);

        reservationGroupBox = new QGroupBox(centralWidget);
        reservationGroupBox->setObjectName("reservationGroupBox");
        verticalLayout_3 = new QVBoxLayout(reservationGroupBox);
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setContentsMargins(11, 11, 11, 11);
        verticalLayout_3->setObjectName("verticalLayout_3");
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName("horizontalLayout_5");
        confirmPushButton = new QPushButton(reservationGroupBox);
        confirmPushButton->setObjectName("confirmPushButton");

        horizontalLayout_5->addWidget(confirmPushButton);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer);

        cancelPushButton = new QPushButton(reservationGroupBox);
        cancelPushButton->setObjectName("cancelPushButton");

        horizontalLayout_5->addWidget(cancelPushButton);


        verticalLayout_3->addLayout(horizontalLayout_5);


        verticalLayout_2->addWidget(reservationGroupBox);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName("horizontalLayout");
        labelMagenta = new QLabel(centralWidget);
        labelMagenta->setObjectName("labelMagenta");

        horizontalLayout->addWidget(labelMagenta);

        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_5);

        labelGreen = new QLabel(centralWidget);
        labelGreen->setObjectName("labelGreen");

        horizontalLayout->addWidget(labelGreen);


        verticalLayout_2->addLayout(horizontalLayout);

        labelRed = new QLabel(centralWidget);
        labelRed->setObjectName("labelRed");

        verticalLayout_2->addWidget(labelRed);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_2);


        horizontalLayout_4->addLayout(verticalLayout_2);


        gridLayout_2->addLayout(horizontalLayout_4, 0, 0, 1, 1);

        hotelClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(hotelClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 886, 22));
        menuFile = new QMenu(menuBar);
        menuFile->setObjectName("menuFile");
        menuAccount = new QMenu(menuBar);
        menuAccount->setObjectName("menuAccount");
        hotelClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(hotelClass);
        mainToolBar->setObjectName("mainToolBar");
        hotelClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(hotelClass);
        statusBar->setObjectName("statusBar");
        hotelClass->setStatusBar(statusBar);
        dockWidget = new QDockWidget(hotelClass);
        dockWidget->setObjectName("dockWidget");
        dockWidget->setStyleSheet(QString::fromUtf8("background-color: rgb(162, 162, 162);"));
        dockWidgetContents = new QWidget();
        dockWidgetContents->setObjectName("dockWidgetContents");
        gridLayout = new QGridLayout(dockWidgetContents);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName("gridLayout");
        verticalLayout_14 = new QVBoxLayout();
        verticalLayout_14->setSpacing(6);
        verticalLayout_14->setObjectName("verticalLayout_14");
        labelContact = new QLabel(dockWidgetContents);
        labelContact->setObjectName("labelContact");
        QFont font;
        font.setPointSize(12);
        labelContact->setFont(font);
        labelContact->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        verticalLayout_14->addWidget(labelContact);

        labelEmail = new QLabel(dockWidgetContents);
        labelEmail->setObjectName("labelEmail");
        labelEmail->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        verticalLayout_14->addWidget(labelEmail);

        labelPhone = new QLabel(dockWidgetContents);
        labelPhone->setObjectName("labelPhone");
        labelPhone->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        verticalLayout_14->addWidget(labelPhone);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_14->addItem(verticalSpacer_4);


        gridLayout->addLayout(verticalLayout_14, 0, 0, 1, 1);

        verticalLayout_16 = new QVBoxLayout();
        verticalLayout_16->setSpacing(6);
        verticalLayout_16->setObjectName("verticalLayout_16");
        labelSocial = new QLabel(dockWidgetContents);
        labelSocial->setObjectName("labelSocial");
        labelSocial->setFont(font);
        labelSocial->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        verticalLayout_16->addWidget(labelSocial);

        labelFacebook = new QLabel(dockWidgetContents);
        labelFacebook->setObjectName("labelFacebook");
        labelFacebook->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        verticalLayout_16->addWidget(labelFacebook);

        labelTelegram = new QLabel(dockWidgetContents);
        labelTelegram->setObjectName("labelTelegram");
        labelTelegram->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        verticalLayout_16->addWidget(labelTelegram);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setSpacing(6);
        horizontalLayout_9->setObjectName("horizontalLayout_9");
        labelInstagram = new QLabel(dockWidgetContents);
        labelInstagram->setObjectName("labelInstagram");
        labelInstagram->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        horizontalLayout_9->addWidget(labelInstagram);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setSpacing(6);
        horizontalLayout_8->setObjectName("horizontalLayout_8");
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_8->addItem(horizontalSpacer_3);

        pushButtonUa = new QPushButton(dockWidgetContents);
        pushButtonUa->setObjectName("pushButtonUa");

        horizontalLayout_8->addWidget(pushButtonUa);

        pushButtonEng = new QPushButton(dockWidgetContents);
        pushButtonEng->setObjectName("pushButtonEng");

        horizontalLayout_8->addWidget(pushButtonEng);


        horizontalLayout_9->addLayout(horizontalLayout_8);


        verticalLayout_16->addLayout(horizontalLayout_9);


        gridLayout->addLayout(verticalLayout_16, 0, 2, 1, 1);

        verticalLayout_15 = new QVBoxLayout();
        verticalLayout_15->setSpacing(6);
        verticalLayout_15->setObjectName("verticalLayout_15");
        labelAddress_1 = new QLabel(dockWidgetContents);
        labelAddress_1->setObjectName("labelAddress_1");
        labelAddress_1->setFont(font);
        labelAddress_1->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        verticalLayout_15->addWidget(labelAddress_1);

        labelAddress_2 = new QLabel(dockWidgetContents);
        labelAddress_2->setObjectName("labelAddress_2");
        labelAddress_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));

        verticalLayout_15->addWidget(labelAddress_2);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_15->addItem(verticalSpacer_3);


        gridLayout->addLayout(verticalLayout_15, 0, 1, 1, 1);

        verticalSpacer_5 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer_5, 1, 2, 1, 1);

        dockWidget->setWidget(dockWidgetContents);
        hotelClass->addDockWidget(Qt::BottomDockWidgetArea, dockWidget);

        menuBar->addAction(menuFile->menuAction());
        menuBar->addAction(menuAccount->menuAction());
        menuFile->addAction(actionInvoice);
        menuFile->addAction(actionSelectRoomsFile);
        menuFile->addAction(actionEditUsers);
        menuAccount->addAction(actionLogOut);

        retranslateUi(hotelClass);

        toolBox->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(hotelClass);
    } // setupUi

    void retranslateUi(QMainWindow *hotelClass)
    {
        hotelClass->setWindowTitle(QCoreApplication::translate("hotelClass", "hotel", nullptr));
        actionInvoice->setText(QCoreApplication::translate("hotelClass", "Invoice", nullptr));
        actionLogOut->setText(QCoreApplication::translate("hotelClass", "Log Out", nullptr));
        actionSelectRoomsFile->setText(QCoreApplication::translate("hotelClass", "Select rooms file", nullptr));
        actionEditUsers->setText(QCoreApplication::translate("hotelClass", "Edit users", nullptr));
        actionEditCompanies->setText(QCoreApplication::translate("hotelClass", "Edit companies", nullptr));
        actionEditEmployee->setText(QCoreApplication::translate("hotelClass", "Edit employee", nullptr));
        usersReservationsGroupBox->setTitle(QCoreApplication::translate("hotelClass", "Your reservations", nullptr));
        pushButtonInfo->setText(QCoreApplication::translate("hotelClass", "Info", nullptr));
        toolButton103->setText(QCoreApplication::translate("hotelClass", "103", nullptr));
        toolButton102->setText(QCoreApplication::translate("hotelClass", "102", nullptr));
        toolButton101->setText(QCoreApplication::translate("hotelClass", "101", nullptr));
        toolButton104->setText(QCoreApplication::translate("hotelClass", "104", nullptr));
        toolButton105->setText(QCoreApplication::translate("hotelClass", "105", nullptr));
        toolButton106->setText(QCoreApplication::translate("hotelClass", "106", nullptr));
        toolBox->setItemText(toolBox->indexOf(floor_1), QCoreApplication::translate("hotelClass", "Floor 1 - One bedded rooms", nullptr));
        toolButton203->setText(QCoreApplication::translate("hotelClass", "203", nullptr));
        toolButton202->setText(QCoreApplication::translate("hotelClass", "202", nullptr));
        toolButton201->setText(QCoreApplication::translate("hotelClass", "201", nullptr));
        toolButton204->setText(QCoreApplication::translate("hotelClass", "204", nullptr));
        toolButton205->setText(QCoreApplication::translate("hotelClass", "205", nullptr));
        toolButton206->setText(QCoreApplication::translate("hotelClass", "206", nullptr));
        toolBox->setItemText(toolBox->indexOf(floor_2), QCoreApplication::translate("hotelClass", "Floor 2 - Two bedded rooms", nullptr));
        toolButton302->setText(QCoreApplication::translate("hotelClass", "302", nullptr));
        toolButton301->setText(QCoreApplication::translate("hotelClass", "301", nullptr));
        toolButton303->setText(QCoreApplication::translate("hotelClass", "303", nullptr));
        toolButton304->setText(QCoreApplication::translate("hotelClass", "304", nullptr));
        toolBox->setItemText(toolBox->indexOf(floor3), QCoreApplication::translate("hotelClass", "Floor 3 - Four bedded rooms", nullptr));
        reservationGroupBox->setTitle(QCoreApplication::translate("hotelClass", "Reservation", nullptr));
        confirmPushButton->setText(QCoreApplication::translate("hotelClass", "Confirm", nullptr));
        cancelPushButton->setText(QCoreApplication::translate("hotelClass", "Cancel", nullptr));
        labelMagenta->setText(QCoreApplication::translate("hotelClass", "*magenta date - reservated", nullptr));
        labelGreen->setText(QCoreApplication::translate("hotelClass", "*green date - confirmed reservation", nullptr));
        labelRed->setText(QCoreApplication::translate("hotelClass", "*red date - canceled reservation(except on weekends)", nullptr));
        menuFile->setTitle(QCoreApplication::translate("hotelClass", "File", nullptr));
        menuAccount->setTitle(QCoreApplication::translate("hotelClass", "Account", nullptr));
        labelContact->setText(QCoreApplication::translate("hotelClass", "Contact us", nullptr));
        labelEmail->setText(QCoreApplication::translate("hotelClass", "Email: bookbed@gmail.com", nullptr));
        labelPhone->setText(QCoreApplication::translate("hotelClass", "Telephone: +38 099 888 77 66", nullptr));
        labelSocial->setText(QCoreApplication::translate("hotelClass", "We are in social media", nullptr));
        labelFacebook->setText(QCoreApplication::translate("hotelClass", "Facebook: bookded", nullptr));
        labelTelegram->setText(QCoreApplication::translate("hotelClass", "Telegram: @bookbedbot", nullptr));
        labelInstagram->setText(QCoreApplication::translate("hotelClass", "Instagram: @bookbed", nullptr));
        pushButtonUa->setText(QString());
        pushButtonEng->setText(QString());
        labelAddress_1->setText(QCoreApplication::translate("hotelClass", "Address", nullptr));
        labelAddress_2->setText(QCoreApplication::translate("hotelClass", "st. Shevchenka 9, Kyiv, Ukraine", nullptr));
    } // retranslateUi

};

namespace Ui {
    class hotelClass: public Ui_hotelClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOTEL_H
