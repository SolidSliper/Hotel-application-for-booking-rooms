#pragma once
#include "User.h"

class Company
{
private:
    QString name, usrName;
    bool VAT_payer;

public:
    Company() : name(""), VAT_payer(false) {}
    Company(QString n, QString u, bool v) : name(n), usrName(u), VAT_payer(v) {}
    bool getVAT() { return VAT_payer; }
    QString getName() { return name; }
    QString getUsrName() { return usrName; }
};