﻿#include "hotel.h"

hotel::hotel(QWidget* parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
    e = new entrance();
    database = new editDatabase();
    e->show();
    ui.dockWidget->hide();

    try {

        // Створення екземпляру драйвера
        driver = sql::mysql::get_mysql_driver_instance();

        // Встановлення з'єднання з базою даних
        con = driver->connect("tcp://127.0.0.1:3306", "root", "ROOT1234ROOT");

        // Вибір бази даних
        con->setSchema("hotel");
    }
    catch (sql::SQLException& e) {
        qDebug() << "SQL error: " << e.what();
    }

    e->initializeUsers(con, stmt, res);

    buttonRoom = {
            ui.toolButton101,
            ui.toolButton102,
            ui.toolButton103,
            ui.toolButton104,
            ui.toolButton105,
            ui.toolButton106,
            ui.toolButton201,
            ui.toolButton202,
            ui.toolButton203,
            ui.toolButton204,
            ui.toolButton205,
            ui.toolButton206,
            ui.toolButton301,
            ui.toolButton302,
            ui.toolButton303,
            ui.toolButton304
    };

    ui.pushButtonUa->setStyleSheet("QPushButton#pushButtonUa {"
        "  background-image: url(D:/KEP/project/ua.png);"
        "  background-position: center;"
        "}");
    ui.pushButtonEng->setStyleSheet("QPushButton#pushButtonEng {"
        "  background-image: url(D:/KEP/project/eng.png);"
        "  background-position: center;"
        "}");

    for (auto& button : buttonRoom) {
        connect(button, &QToolButton::clicked, this, &hotel::handleButtonRoomCheck);
    }

    fillRooms();
    setCountRooms();
    checkReservations();

    connect(e, &entrance::loginCompleted, this, &hotel::showWindow);
    connect(ui.listWidget, &QListWidget::itemClicked, this, &hotel::dateReservationSelected);
    connect(ui.actionLogOut, &QAction::triggered, this, &hotel::loggingOut);
    connect(ui.actionSelectRoomsFile, &QAction::triggered, this, &hotel::changeRoomsFile);
    connect(ui.actionEditUsers, &QAction::triggered, this, &hotel::editDatabaseUsers);
    connect(ui.actionInvoice, &QAction::triggered, this, &hotel::createInvoice);
}

hotel::~hotel()
{
    delete res;
    delete stmt;
    delete con;
    delete e;
    delete database;
    saveRooms();
}

void hotel::showWindow() // slot spravny vstup uzera
{
    e->hide();
    show();
    actUsrIndx = e->getIndexActiveUsr();    // pridavanie hodnoty aktivneho uzera
    isG = e->getIsG();                      // stav guest alebo company
    //rbtns = { ui.oneBeddedRadioButton, ui.twoBeddedRadioButton, ui.fourBeddedRadioButton }; // ulozenie radio buttons do vektora
    actionButtons = { ui.actionEditUsers, ui.actionSelectRoomsFile, ui.actionInvoice };     // ulozenie QAction elementov do vektora

    qDebug() << "Index of current user: " << actUsrIndx;

    for (int i = 0; i < 3; ++i)
        typeUsr[i] = e->getActiveUsr(i);     // pridavanie typu uzera

    qDebug() << typeUsr[0] << typeUsr[1] << typeUsr[2];

    if (typeUsr[2] == true) // blok nastavenia UI pre admina alebo recepcneho
    {
        ui.usersReservationsGroupBox->setTitle("Guests reservations");
        for (int i = 0; i < actionButtons.size(); i++)
            actionButtons[i]->setVisible(true);

        ui.actionInvoice->setVisible(false);
        listReservations();
        emp = e->getEmployee();
        admin = emp[actUsrIndx].getAdm();
        recept = emp[actUsrIndx].getRecep();

        if (admin)
            qDebug() << "admin";

        if (recept && admin == false)
        {
            qDebug() << "recept";
            for (int i = 0; i < actionButtons.size(); i++)
                actionButtons[i]->setVisible(false);
        }

        /*for (int i = 0; i < rbtns.size(); i++)
            rbtns[i]->setCheckable(false);*/
    }

    if (typeUsr[0] || typeUsr[1]) // blok nastavenia UI pre hosta
    {
        ui.usersReservationsGroupBox->setTitle("Your reservations");
        for (int i = 0; i < actionButtons.size(); i++)
            actionButtons[i]->setVisible(false);

        ui.actionInvoice->setVisible(true);
        userReservations();

        /*for (int i = 0; i < rbtns.size(); i++)
            rbtns[i]->setCheckable(true);*/
    }
}

void hotel::fillRooms() // metod naplnenia triedy Room
{
    try {
        // Виконання SQL запиту
        stmt = con->createStatement();
        res = stmt->executeQuery("SELECT * FROM rooms");
        // Обробка результатів запиту
        int i = 0;
        while (res->next()) {
            bool free = res->getBoolean("free");
            bool new_reservation = res->getBoolean("new_reservation");
            int index = res->getInt("index_user");
            double price = res->getDouble("price");
            QString type = QString::fromStdString(res->getString("type_room"));
            QDate date = QDate::fromString(QString::fromStdString(res->getString("date")), "yyyy-MM-dd");
            bool isGuest = res->getBoolean("is_guest");

            Room r(free, new_reservation, index, price, type, date, isGuest);
            rooms.push_back(r);
            rooms[i].print();

            i++;
        }
    }
    catch (sql::SQLException& e) {
        qDebug() << "SQL error: " << e.what();
    }
}

void hotel::checkReservations()   // metoda, aka nastavi farbu datumu
{
    for (Room& room : rooms)
    {
        QDate date = room.getDate();
        QTextCharFormat textCharFormat;

        if (room.getFree() && room.getNew()) // якщо нова резервація, то колір дати в календарі буде пурпурний
        {
            textCharFormat.setForeground(Qt::magenta);
            ui.calendarWidget->setDateTextFormat(date, textCharFormat);
        }

        if (!room.getFree() && !room.getNew()) // якщо підтверджена резервація, то колір дати в календарі буде зелений
        {
            textCharFormat.setForeground(Qt::darkGreen);
            ui.calendarWidget->setDateTextFormat(date, textCharFormat);
        }

        if (!room.getFree() && room.getNew()) // якщо відхилена резервація, то колір дати в календарі буде червоний(окрім вихідних)
        {
            textCharFormat.setForeground(Qt::red);
            ui.calendarWidget->setDateTextFormat(date, textCharFormat);
        }
    }
}

void hotel::createListItem(int index, Room& room)
{
    double newPrice;
    bool vat = e->getCompany()[actUsrIndx].getVAT() == true;

    if (e->getActiveUsr(1) == true && vat)   // Vydanie novej ceny, ak je spoločnosť platiteľom
        newPrice = room.getPrice() * 0.8;

    else
        newPrice = room.getPrice();

    QBrush textBrush;
    QString reservation_status;

    if (room.getNew() && room.getFree()) // rovnaké farby ako v kalendári
    {
        reservation_status = "new_reservation";
        textBrush = QBrush(Qt::magenta);
    }

    if (!room.getNew() && !room.getFree())
    {
        reservation_status = "confirmed_reservation";
        textBrush = QBrush(Qt::darkGreen);
    }

    if (room.getNew() && !room.getFree())
    {
        reservation_status = "canceled_reservation";
        textBrush = QBrush(Qt::red);
    }

    QString name, surname, isPayer;
    bool VAT_payer;
    int indxx = actUsrIndx;
    if (typeUsr[2] && room.getIndex() != -1)
        indxx = room.getIndex();

    Company c = e->getCompany()[indxx];
    Guest g = e->getGuest()[indxx];

    if (room.getIsGuest() && room.getIndex() != -1)
    {
        name = " " + g.getName();
        surname = " " + g.getSurname();
    }

    else if (room.getIndex() != -1)
    {
        name = " " + c.getName();
        VAT_payer = c.getVAT();
        if (VAT_payer)
            isPayer = " VAT payer";
        else
            isPayer = " not VAT payer";
    }

    QString listItem = QString::number(index) + " " + room.getType() + " "
        + QString::number(newPrice) + " " + room.getDate().toString("yyyy-MM-dd") + " "
        + reservation_status + name + surname + isPayer;

    QListWidgetItem* newItem = new QListWidgetItem(listItem);
    newItem->setForeground(textBrush);
    ui.listWidget->addItem(newItem);
}

void hotel::userReservations() // Metóda výpisu rezervácií pre daného hosťa
{
    ui.listWidget->clear();  // Vyčistenie QListWidget pred pridaním nových položiek

    for (int i = 0; i < rooms.size(); ++i)
        if (rooms[i].getIndex() == actUsrIndx && rooms[i].getIsGuest() == isG)
            createListItem(i, rooms[i]);
}

void hotel::listReservations() // Metóda výpisu rezervácií rezervácií všetkých hostí
{
    ui.listWidget->clear();

    for (int i = 0; i < rooms.size(); ++i)
        createListItem(i, rooms[i]);
}

void hotel::setCountRooms()
{
    int a = 0;
    int b = 0;
    int c = 0;
    for (Room& room : rooms)
    {
        if (room.getFree() == true)
        {
            if (room.getType() == "oneBedded")
                a++;

            else if (room.getType() == "twoBedded")
                b++;

            else if (room.getType() == "fourBedded")
                c++;
        }
    }
    //ui.oneBeddedSpinBox->setValue(a);
    //ui.twoBeddedSpinBox->setValue(b);
    //ui.fourBeddedSpinBox->setValue(c);
}

void hotel::on_confirmPushButton_clicked() // метод підтвердження резервації
{
    if (ui.calendarWidget->selectedDate().isNull())
    {
        QMessageBox::warning(this, "Select date", "Select date for reservation!");
        return;
    }

    if (ui.calendarWidget->selectedDate() < QDate::currentDate())
    {
        QMessageBox::warning(this, "Wrong date", "Choose a correct date!");
        return;
    }

    QDate selectedDate = ui.calendarWidget->selectedDate();
    QColor textColor = ui.calendarWidget->dateTextFormat(selectedDate).foreground().color();

    if (typeUsr[2])
        confirmGuestReservation(selectedDate, textColor);
    else
        confirmRegularReservation(textColor);
}

void hotel::confirmGuestReservation(const QDate& selectedDate, const QColor& textColor) // метод підтвердження резервації
{
    for (Room& room : rooms)
    {
        if (room.getFree() && room.getNew() && textColor == Qt::magenta && selectedDate == room.getDate())
        {
            room.setNew(false);
            room.setFree(false);
            room.print();
            break;
        }
    }

    saveRooms();
    setCountRooms();
    checkReservations();
    listReservations();
}

void hotel::confirmRegularReservation(const QColor& textColor) // метод резервації
{
    bool reservationAvaliable = false;

    if (rooms[selectedRoomIndex].getFree() && !rooms[selectedRoomIndex].getNew() && textColor == Qt::black && selectedRoomIndex != -1)
    {
        buttonRoom[selectedRoomIndex]->setStyleSheet("background-color: rgb(255, 0, 0);");
        rooms[selectedRoomIndex].setIndex(actUsrIndx);
        rooms[selectedRoomIndex].setNew(true);
        rooms[selectedRoomIndex].setDate(ui.calendarWidget->selectedDate());
        rooms[selectedRoomIndex].setIsGuest(isG);
        rooms[selectedRoomIndex].print();
        reservationAvaliable = true;
    }

    saveRooms();
    checkReservations();
    userReservations();
}

void hotel::on_cancelPushButton_clicked() //метод відміни резервації
{
    const QDate selectedDate = ui.calendarWidget->selectedDate();

    int i = 0;
    for (Room& room : rooms)
    {
        if (selectedDate == room.getDate() && room.getFree() && isEmployee())
        {
            buttonRoom[i]->setStyleSheet("background-color: palette(midlight);");
            cancelAdminReservation(room, false);
            break;
        }

        if (selectedDate == room.getDate() && !room.getFree() && room.getNew() && isEmployee())
        {
            buttonRoom[i]->setStyleSheet("background-color: palette(midlight);");
            cancelAdminReservation(room, true);
            break;
        }

        if (selectedDate == room.getDate() && actUsrIndx == room.getIndex() && room.getFree() && isG == room.getIsGuest())
        {
            buttonRoom[i]->setStyleSheet("background-color: palette(midlight);");
            cancelGuestReservation(room);
            break;
        }

        i++;
    }
    checkReservations();
}

void hotel::cancelAdminReservation(Room& room, bool true_or_false) // відміна резервації працівником готелю
{
    room.setNew(!true_or_false);
    room.setFree(true_or_false);

    if (true_or_false)
    {
        setBlackReservations(room);
        room.setIndex(-1);
        room.setDate(QDate(10, 10, 10));
    }

    setCountRooms();
    listReservations();
    saveRooms();
    room.print();
}

void hotel::cancelGuestReservation(Room& room) // відміна резервації гостем
{
    setBlackReservations(room);
    room.setNew(false);
    room.setFree(true);
    room.setIndex(-1);
    room.setDate(QDate(10, 10, 10));
    userReservations();
    saveRooms();
    room.print();
}

void hotel::setBlackReservations(const Room& room) // зміна на чорний текст в календарі
{
    const QDate date = room.getDate();
    QTextCharFormat textCharFormat;
    textCharFormat.setForeground(Qt::black);
    ui.calendarWidget->setDateTextFormat(date, textCharFormat);
}

void hotel::dateReservationSelected(QListWidgetItem* item)
{
    QString line = item->text();
    QStringList parts = line.split(" ");
    selectedDateRes = QDate::fromString(parts[3], "yyyy-MM-dd");
    ui.calendarWidget->setSelectedDate(selectedDateRes);
}

void hotel::changeRoomsFile()
{
    QFileDialog dialog(this);
    filename = QFileDialog::getOpenFileName(this, tr("Open File"), "", tr("Text files (*.txt);;All files (*.*)"));

    if (!filename.isEmpty()) {
        rooms.clear();
        fillRooms();
        for (Room& room : rooms)
            setBlackReservations(room);
        checkReservations();
        listReservations();
        setCountRooms();
    }
}

void hotel::editDatabaseUsers()
{
    database = new editDatabase();
    database->show();
}

void hotel::createInvoice()
{
    QFileDialog dialog(this);
    QString filePath = QFileDialog::getSaveFileName(this, tr("Save File"), "", tr("Text Files (*.txt);;All Files (*)"));

    QFile file(filePath);

    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream out(&file);
        int i = 0;
        double countPrice = 0;
        if (isG)
        {
            Guest guest = e->getGuest()[actUsrIndx];
            out << "Name: " << guest.getName() << " Surname: " << guest.getSurname() << " Billing adress: " << guest.getBill() << '\n';
            for (Room& room : rooms)
            {
                if (room.getIndex() == actUsrIndx && room.getIsGuest() == isG && room.getNew() && room.getFree())
                {
                    out << i << " " << room.getType() << " " << room.getDate().toString("yyyy-MM-dd") << " " << room.getPrice() << " euro\n";
                    countPrice += room.getPrice();
                }
                i++;
            }
            out << "To pay: " << countPrice;
        }
        else
        {
            Company company = e->getCompany()[actUsrIndx];
            out << "Name: " << company.getName() << " Vat payer: " << company.getVAT() << '\n';
            for (Room& room : rooms)
            {
                if (room.getIndex() == actUsrIndx && room.getIsGuest() == isG && room.getNew() && room.getFree())
                {
                    double newPrice;
                    if (company.getVAT())
                        newPrice = room.getPrice() * 0.8;
                    else
                        newPrice = room.getPrice();

                    out << i << " " << room.getType() << " " << room.getDate().toString("yyyy-MM-dd") << " " << newPrice << " euro\n";
                    countPrice += newPrice;
                }
                i++;
            }
            out << "To pay: " << countPrice;
        }
    }
}

void hotel::saveRooms()
{
    try {
        // Виконання SQL запиту для оновлення даних
        stmt = con->createStatement();
        stmt->execute("TRUNCATE TABLE rooms"); // Очистити таблицю перед оновленням даних

        // Підготовка SQL-запиту для вставки даних
        sql::PreparedStatement* pstmt = con->prepareStatement(
            "INSERT INTO rooms (free, new_reservation, index_user, price, type_room, date, is_guest) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)"
        );

        // Оновлення даних у таблиці
        for (Room& room : rooms)
        {
            pstmt->setBoolean(1, room.getFree());
            pstmt->setBoolean(2, room.getNew());
            pstmt->setInt(3, room.getIndex());
            pstmt->setDouble(4, room.getPrice());
            pstmt->setString(5, room.getType().toStdString());
            pstmt->setString(6, room.getDate().toString("yyyy-MM-dd").toStdString());
            pstmt->setBoolean(7, room.getIsGuest());

            pstmt->execute();
        }

        // Звільнення ресурсів
        delete pstmt;

    }
    catch (sql::SQLException& e) {
        qDebug() << "SQL error: " << e.what();
    }
}

//void hotel::handleButtonRoomCheck()
//{
//    QToolButton* clickedButton = qobject_cast<QToolButton*>(sender());
//    if (clickedButton->isChecked())
//        selectedRoomIndex = buttonRoom[clickedButton];
//    else
//        selectedRoomIndex = -1;
//
//    qDebug() << "Selected room: " << selectedRoomIndex;
//
//    for (auto& pair : buttonRoom) {
//        QToolButton* button = pair.first;
//        int index = pair.second;
//
//        if (index != selectedRoomIndex && button->isChecked()) {
//            button->setChecked(false);
//        }
//    }
//}

void hotel::handleButtonRoomCheck()
{
    QToolButton* clickedButton = qobject_cast<QToolButton*>(sender());

    selectedRoomIndex = -1;
    for (int i = 0; i < buttonRoom.size(); i++)
    {
        if (clickedButton == buttonRoom[i])
        {
            selectedRoomIndex = i;
            break;
        }
    }

    qDebug() << "Selected room: " << selectedRoomIndex;

    for (int i = 0; i < buttonRoom.size(); i++) {

        if (i != selectedRoomIndex && buttonRoom[i]->isChecked()) {
            buttonRoom[i]->setChecked(false);
        }
    }
}

void hotel::on_pushButtonInfo_clicked()
{
    if (ui.dockWidget->isHidden())
        ui.dockWidget->show();
    else
        ui.dockWidget->hide();
}

void hotel::on_pushButtonUa_clicked()
{
    ui.usersReservationsGroupBox->setTitle("Ваші резервації"); 
    ui.reservationGroupBox->setTitle("Резервація");
    ui.toolBox->setItemText(0, "1 поверх - одномісні номери");
    ui.toolBox->setItemText(1, "2 поверх - двомісні номери");
    ui.toolBox->setItemText(2, "3 поверх - чотиримісні номери");
    ui.pushButtonInfo->setText("Інформація");
    ui.cancelPushButton->setText("Відмінити");
    ui.confirmPushButton->setText("Підтвердити");
    ui.labelMagenta->setText("пурпурна дата - нова резервація");
    ui.labelGreen->setText("зелена дата - підтверджена резервація");
    ui.labelRed->setText("червона дата - відмінена резервація(окрім вихідних)");
    ui.labelContact->setText("Зв'яжіться з нами");
    ui.labelAddress_1->setText("Адреса");
    ui.labelAddress_2->setText("вул. Шевченка 9, Київ, Україна");
    ui.labelSocial->setText("Ми в соцмережах");
}

void hotel::on_pushButtonEng_clicked()
{
    ui.usersReservationsGroupBox->setTitle("Your reservations");
    ui.reservationGroupBox->setTitle("Reservation");
    ui.toolBox->setItemText(0, "Floor 1 - one bedded rooms");
    ui.toolBox->setItemText(1, "Floor 2 - two bedded rooms");
    ui.toolBox->setItemText(2, "Floor 3 - four bedded rooms");
    ui.pushButtonInfo->setText("Info");
    ui.cancelPushButton->setText("Cancel");
    ui.confirmPushButton->setText("Confirm");
    ui.labelMagenta->setText("*magenta date - reservated");
    ui.labelGreen->setText("*green date - confirmed reservation");
    ui.labelRed->setText("*red date - canceled reservation(except on weekends)");
    ui.labelContact->setText("Contact us");
    ui.labelAddress_1->setText("Address");
    ui.labelAddress_2->setText("st. Shevchenka 9, Kyiv, Ukraine");
    ui.labelSocial->setText("We are in social media");
}

void hotel::loggingOut()
{
    for (int i = 0; i < 3; i++)
        typeUsr[i] = false;

    admin = false;
    recept = false;
    hide();
    e->setActiveUsrDefault();
    e->show();
    //spnbxss.clear();
    //rbtns.clear();
    actionButtons.clear();
    saveRooms();
}