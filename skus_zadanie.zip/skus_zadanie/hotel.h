#pragma once

#include <QtWidgets/QMainWindow>
#include <QStandardItem>
#include <QFileDialog>
#include "ui_hotel.h"
#include "entrance.h"
#include "editDatabase.h"
#include "Room.h"
#include <mysql_connection.h>
#include <mysql_driver.h>
#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/prepared_statement.h>
#include <cppconn/statement.h>

#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>

class hotel : public QMainWindow
{
    Q_OBJECT

public:
    hotel(QWidget* parent = nullptr);
    ~hotel();

private:
    Ui::hotelClass ui;
    entrance* e;
    editDatabase* database;
    QVector<Room> rooms;
    //std::unordered_map<QToolButton*, int> buttonRoom;
    QVector<QToolButton*> buttonRoom;

    int countRooms, countOneBed, countTwoBed, countFourBed, actUsrIndx, selectedRoomIndex = -1;
    bool typeUsr[3] = { false, false, false };
    bool admin = false;
    bool recept = false;
    bool isG = true;
    QVector<Employee> emp;
    QString filename = "Database/rooms.txt";          
    QList<QString> types_of_rooms = { "oneBedded", "twoBedded", "fourBedded" };
    QList<QAction*> actionButtons;
    QDate selectedDateRes;

    sql::mysql::MySQL_Driver* driver;
    sql::Connection* con;
    sql::Statement* stmt;
    sql::ResultSet* res;

    void fillRooms();
    void saveRooms();
    void listReservations();
    void userReservations();
    void setCountRooms();
    void checkReservations();
    void createListItem(int index, Room& room);
    void confirmGuestReservation(const QDate& selectedDate, const QColor& textColor);
    void confirmRegularReservation(const QColor& textColor);
    void cancelAdminReservation(Room& room, bool true_or_false);
    void cancelGuestReservation(Room& room);
    void setBlackReservations(const Room& room);
    bool isEmployee()
    {
        if (typeUsr[2] == true)
            return true;
        else
            return false;
    }

private slots:
    void showWindow();
    void loggingOut();
    void dateReservationSelected(QListWidgetItem* item);
    void changeRoomsFile();
    void editDatabaseUsers();
    void createInvoice();
    void handleButtonRoomCheck();

    void on_confirmPushButton_clicked();
    void on_cancelPushButton_clicked();
    void on_pushButtonInfo_clicked();
    void on_pushButtonUa_clicked();
    void on_pushButtonEng_clicked();
};