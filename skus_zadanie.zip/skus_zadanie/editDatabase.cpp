#include "editDatabase.h"

editDatabase::editDatabase(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);

	connect(ui.actionOpen, SIGNAL(triggered()), this, SLOT(putDataToEdit()));
	connect(ui.editPushButton, SIGNAL(clicked()), this, SLOT(editData()));
	connect(ui.exitPushButton, SIGNAL(clicked()), this, SLOT(exit()));
}

editDatabase::~editDatabase()
{}

void editDatabase::putDataToEdit()
{
	QFileDialog dialog(this);
	filename = QFileDialog::getOpenFileName(this, tr("Open File"), "", tr("Text files (*.txt);;All files (*.*)"));

	QFile file(filename);

	if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
		QTextStream in(&file);
		ui.textEdit->setPlainText(in.readAll());
		file.close();
	}
	else
	{
		QMessageBox::warning(this, "Error", "File could not be opened: " + file.errorString());
	}
}

void editDatabase::editData()
{
	QString line = ui.textEdit->toPlainText();
	QStringList parts = line.split(" ");
	if (ui.textEdit->toPlainText().isEmpty() || parts[4].toInt()==0 && ui.employeeCheckBox->isChecked())
	{
		QMessageBox::warning(this, "Error", "Must be at least 1 administrator in first row!");
		return;
	}

	QFile file(filename);

	if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
		QTextStream out(&file);
		out << ui.textEdit->toPlainText();
		file.close();
		QMessageBox::information(this, "Succses", "File has been successfully edited");
	}
	else
	{
		QMessageBox::warning(this, "Error", "File could not be opened: " + file.errorString());
	}
}

void editDatabase::exit()
{
	close();
}