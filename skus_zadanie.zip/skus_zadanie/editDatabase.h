#pragma once

#include <QMainWindow>
#include <QFileDialog>+
#include <QMessageBox>
#include "ui_editDatabase.h"

class editDatabase : public QMainWindow
{
	Q_OBJECT

public:
	editDatabase(QWidget *parent = nullptr);
	~editDatabase();

private:
	Ui::editDatabaseClass ui;
	QString filename;

private slots:
	void putDataToEdit();
	void editData();
	void exit();
};
